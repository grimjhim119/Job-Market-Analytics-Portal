
import pandas as pd

df = pd.read_csv("../data/raw_jobs.csv")
df.drop_duplicates(inplace=True)
df.to_csv("../data/clean_jobs.csv", index=False)
print("ETL completed")
