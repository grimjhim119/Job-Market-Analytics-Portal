
import pandas as pd

data = {
    "job_title": ["Data Analyst", "Business Analyst"],
    "company": ["ABC Corp", "XYZ Ltd"],
    "location": ["Bangalore", "Delhi"],
    "salary": [600000, 700000],
    "skills": ["Python, SQL, Pandas", "Excel, SQL, Visualization"]
}

df = pd.DataFrame(data)
df.to_csv("../data/raw_jobs.csv", index=False)
print("Scraping completed")
